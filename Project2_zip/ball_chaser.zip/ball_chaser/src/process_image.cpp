#include "ros/ros.h"

#include "ball_chaser/DriveToTarget.h"

#include <sensor_msgs/Image.h>



// Define global vector of joints last position, moving state of the arm, and the client that can request services

ros::ServiceClient client;



// This function calls the safe_move service to safely move the arm to the center position

void move_robot(double x, double z)

{

    ROS_INFO_STREAM("Moving robot forward");



    // Request robot movement

    ball_chaser::DriveToTarget srv;

    srv.request.linear_x = x;

    srv.request.angular_z = z;



    // Call the command_robot service and pass the requested robot movement

    if (!client.call(srv))

        ROS_ERROR("Failed to call service safe_move");

}



// This callback function continuously reads the camera images and identifies the balls position

void process_image_callback(const sensor_msgs::Image im)

{
    // placeholder for the ball direction
    double direction = 0;

    // Analyse if ball present
    for (int i = 0; i < im.height * im.step; i++) {
        if (im.data[i] == 255) {
            direction = (i % im.step);
            break;
        }
    }

    ROS_INFO("the direction is:%1.2f inside a width of %d: ", (float)direction, im.step);

    // Determine direction of movement
    if (direction == 0) {
        move_robot(0.0, 0.0);
    } else if (direction < im.step / 3) {
        move_robot(0.1, 0.1);
    } else if (direction > 2 * im.step / 3) {
        move_robot(0.1, -0.1);
    } else {
        move_robot(0.1, 0.0);
    }
}



int main(int argc, char** argv)

{

    // Initialize the process image node and create a handle to it

    ros::init(argc, argv, "process_image");

    ros::NodeHandle n;



    // Define a client service capable of requesting services from command_robot

    client = n.serviceClient<ball_chaser::DriveToTarget>("/ball_chaser/command_robot");



    // Subscribe to /camera/rgb/image_raw topic to read the image and identify the balls position inside the process_image_callback function

    ros::Subscriber sub1 = n.subscribe("/camera/rgb/image_raw", 1, process_image_callback);


    // Handle ROS communication events

    ros::spin();



    return 0;

}
