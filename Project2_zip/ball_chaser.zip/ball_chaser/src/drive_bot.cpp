#include "ros/ros.h"
#include "ball_chaser/DriveToTarget.h"
#include "geometry_msgs/Twist.h"

// Global motor velocity publisher variables
ros::Publisher motor_command_publisher;

// This callback function executes whenever a safe_move service is requested
bool handle_ball_chassing_request(ball_chaser::DriveToTarget::Request& req,
    ball_chaser::DriveToTarget::Response& res)
{

    ROS_INFO("DriveToTarget received - x:%1.2f, z:%1.2f", (float)req.linear_x, (float)req.angular_z);

    // Check the position of the ball
    float x = req.linear_x;
    float z = req.angular_z;

    // Publish twist for the robot
    geometry_msgs::Twist motor_command;

    // Set wheel velocities from service request
    motor_command.linear.x = x;
    motor_command.angular.z = z;

    // Publish angles to drive the robot
    motor_command_publisher.publish(motor_command);

    // Wait 3 seconds for arm to settle
    ros::Duration(3).sleep();

    // Return a response message
    res.msg_feedback = "Robot x velocity set to: " + std::to_string(x) + ", and z velocity to: " + std::to_string(z);
    ROS_INFO_STREAM(res.msg_feedback);

    return true;
}

int main(int argc, char** argv)
{
    // Initialize the arm_mover node and create a handle to it
    ros::init(argc, argv, "drive_bot");
    ros::NodeHandle n;

    // Define two publishers to publish std_msgs::Float64 messages on joints respective topics
    motor_command_publisher = n.advertise<geometry_msgs::Twist>("/cmd_vel", 10);

    // Define a safe_move service with a handle_safe_move_request callback function
    ros::ServiceServer service = n.advertiseService("/ball_chaser/command_robot", handle_ball_chassing_request);
    ROS_INFO("Ready to send joint commands");

    // Handle ROS communication events
    ros::spin();

    return 0;
}
